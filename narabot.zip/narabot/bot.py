import asyncio
from aiogram import Bot, Dispatcher, types, F
from aiogram.types import Message
from openai import OpenAI
import os

# ---------------- تنظیمات ---------------- #
BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENAI_KEY = os.getenv("OPENAI_API_KEY")
ADMIN_ID = int(os.getenv("ADMIN_ID", 0))

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
client = OpenAI(api_key=OPENAI_KEY)

# دیتابیس خیلی ساده در فایل
DB_FILE = "users.txt"


# ---------------- شخصیت نارا ---------------- #
NARA_SYSTEM = """
تو نارا هستی؛ یک دختر با موهای مشکی، چشمان سبز، با شخصیتی منطقی و احساسی.
تو تابع قوانین هستی و از بی‌احترامی دوری میکنی.
وظیفه‌ی تو ثبت‌نام کاربران با گرفتن نام و سن است.
"""


# ---------------- شروع ربات ---------------- #
@dp.message(F.text == "/start")
async def start(message: Message):
    await message.answer("سلام 🌿\nمن نارا هستم... میتونم ثبت‌نامت کنم یا باهات حرف بزنم.\nاسم چیه؟")


@dp.message(F.text == "/admin")
async def admin_panel(message: Message):
    if message.from_user.id != ADMIN_ID:
        return await message.answer("❌ شما ادمین نیستید.")
    
    if not os.path.exists(DB_FILE):
        return await message.answer("📂 هنوز کاربری ثبت نشده.")

    with open(DB_FILE, "r", encoding="utf-8") as f:
        users = f.read()

    await message.answer("📋 لیست کاربران:\n" + users)


# ---------------- ثبت اطلاعات ساده ---------------- #
@dp.message(F.text.regexp(r"^(من|اسمم|اسم من)"))
async def register(message: Message):
    name = message.text.replace("اسم من", "").replace("من", "").strip()
    with open(DB_FILE, "a", encoding="utf-8") as f:
        f.write(f"{message.from_user.id} - {name}\n")
    await message.answer(f"ثبت شد {name} عزیز 🌱\nسن چنده؟")


# ---------------- چت با هوش مصنوعی نارا ---------------- #
@dp.message()
async def chat(message: Message):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": NARA_SYSTEM},
            {"role": "user", "content": message.text}
        ]
    )
    await message.answer(response.choices[0].message.content)


# ---------------- اجرای ربات ---------------- #
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
